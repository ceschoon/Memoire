#! /bin/bash

gnuplot   coexCurveLS.gp

pdflatex  coexCurveLS.tex

rm   coexCurveLS.aux   coexCurveLS.log   coexCurveLS.tex   coexCurveLS-inc.eps   coexCurveLS-inc-eps-converted-to.pdf

